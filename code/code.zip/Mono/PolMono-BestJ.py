#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Jan 11 10:36:59 2020

@author: lester
"""
from collections import namedtuple
from cv2.ximgproc import guidedFilter
from net.losses import StdLoss
from utils.imresize import imresize, np_imresize
from utils.image_io import *
from skimage.color import rgb2hsv
import torch
import torch.nn as nn
from net.vae import VAE
import numpy as np
from net.Net_color1 import Net, Net2
from options2 import options2
from TVLoss.L1_TVLoss import L1_TVLoss_Charbonnier
from Gloss.Gsmoothloss import conlight_loss
from Gloss.GClaheloss import *
from loss_vgg import VggLoss
import torch.nn.functional as F
from modeling.fpn import *


os.environ["CUDA_VISIBLE_DEVICES"] = "7,8,9"
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')


def get_dark_channel(image, w=15):
    """
    Get the dark channel prior in the (RGB) image data.
    Parameters
    -----------
    image:  an M * N * 3 numpy array containing data ([0, L-1]) in the image where
        M is the height, N is the width, 3 represents R/G/B channels.
    w:  window size
    Return
    -----------
    An M * N array for the dark channel prior ([0, L-1]).
    """
    M, N, _ = image.shape
    padded = np.pad(image, ((w // 2, w // 2), (w // 2, w // 2), (0, 0)), 'edge')
    darkch = np.zeros((M, N))
    for i, j in np.ndindex(darkch.shape):
        darkch[i, j] = np.min(padded[i:i + w, j:j + w, :])  # CVPR09, eq.5
    return darkch


def get_atmosphere(image, p=0.0001, w=15):
    """Get the atmosphere light in the (RGB) image data.
    Parameters
    -----------
    image:      the 3 * M * N RGB image data ([0, L-1]) as numpy array
    w:      window for dark channel
    p:      percentage of pixels for estimating the atmosphere light
    Return
    -----------
    A 3-element array containing atmosphere light ([0, L-1]) for each channel
    """
    # image = image.transpose(1, 2, 0)
    # # reference CVPR09, 4.4
    # darkch = get_dark_channel(image, w)
    # M, N = darkch.shape
    # flatI = image.reshape(M * N, 3)
    # flatdark = darkch.ravel()
    # searchidx = (-flatdark).argsort()[:int(M * N * p)]  # find top M * N * p indexes
    # # return the highest intensity for each channel
    # return np.max(flatI.take(searchidx, axis=0), axis=0)
    """
    change to one channel
    """
    a = np.max(image)
    return a


DehazeResult_PYOLY = namedtuple("DehazeResult", ['learned', 'a', 't', 'S_res', 'I_res', 'R_res', 'P_res','S_Ori'])


class Dehaze(object):

    def __init__(self, image_name, I0, I90, opt):
        self.image_name = image_name
        self.I0 = I0
        self.I90 = I90
        self.num_iter = opt.num_iter

        self.ambient_net = None
        self.image_net = None
        self.mask_net = None
        self.ambient_val = None
        self.mse_loss = None
        self.learning_rate = opt.learning_rate
        self.parameters = None
        self.current_result = None
        self.output_path = "output/" + opt.datasets + '_J_new/'
        self.patch_size = 4
        self.data_type = torch.cuda.FloatTensor
        self.clip = opt.clip
        self.blur_loss = None
        self.best_result = None
        self.best_result_ssim = None
        self.image_net_inputs = None
        self.mask_net_inputs = None
        self.image_out = None
        self.mask_out = None
        self.ambient_out = None
        self.total_loss = None
        self._init_all()

        self.input = None
        self.output = None

        self.seg = fpn(opt.num_of_SegClass).to(device)
        self.seg_criterion = FocalLoss(gamma=2).to(device)
    def _init_images(self):
        self.original_image = self.I0.copy()
        factor = 1
        image_I0 = self.I0
        image_I90 = self.I90
        image_size = 1000

        while image_I0.shape[1] >= image_size or image_I0.shape[2] >= image_size:
            new_shape_x, new_shape_y = self.I0.shape[1] / factor, self.I0.shape[2] / factor
            new_shape_x -= (new_shape_x % 32)
            new_shape_y -= (new_shape_y % 32)
            image_I0 = np_imresize(self.I0, output_shape=(new_shape_x, new_shape_y))
            image_I90 = np_imresize(self.I90, output_shape=(new_shape_x, new_shape_y))
            factor = 1 + factor

        self.I0 = image_I0
        self.I90 = image_I90

        self.I0_torch = np_to_torch(self.I0).type(torch.cuda.FloatTensor)
        self.I90_torch = np_to_torch(self.I90).type(torch.cuda.FloatTensor)

    def _init_nets(self):
        J_net = Net2(out_channel=1)
        R_net = Net2(out_channel=1)
        A_net = Net2(out_channel=1)
        t_net = Net(out_channel=1)
        # PD_NET = Net(out_channel=1)
        # PA_NET = Net(out_channel=1)

        self.J_net = J_net.type(self.data_type)
        self.R_net = R_net.type(self.data_type)
        self.A_net = A_net.type(self.data_type)
        self.t_net = t_net.type(self.data_type)
        # self.PD_NET = PD_NET.type(self.data_type)
        # self.PA_NET = PA_NET.type(self.data_type)

    def _init_ambient(self):
        ambient_net = VAE(self.I0.shape)

        self.ambient_net = ambient_net.type(torch.cuda.FloatTensor)
        atmosphere = get_atmosphere(self.I0)

        self.ambient_val = nn.Parameter(data=torch.cuda.FloatTensor(atmosphere.reshape((1, 1, 1, 1))),
                                        requires_grad=False)

    def _init_parameters(self):
        parameters = [p for p in self.J_net.parameters()] +  \
                     [p for p in self.R_net.parameters()] + \
                     [p for p in self.t_net.parameters()] +  \
                     [p for p in self.ambient_net.parameters()]

        self.parameters = parameters

    def eme_loss(self, img, k1=5, k2=5):
        x_number = int(img.shape[2] / k1)
        y_number = int(img.shape[3] / k2)
        # torch.ones
        eme = 0.
        for j in range(y_number):
            for i in range(x_number):
                patch = img[0, 0, k1 * i: k1 * (i + 1), k2 * j: k2 * (j + 1)]
                patch_min = torch.min(patch)
                patch_max = torch.max(patch)

                patch_ratio = patch_max / (patch_min + 1e-4)
                eme = 20. * torch.log(patch_ratio) + eme
        # print(eme)
        # print((x_number * y_number) / (eme + 0.0001))
        return (x_number * y_number) / eme

    def eme_loss2(self, img1,img2, k1=15, k2=15):
        x_number = int(img1.shape[2] / k1)
        y_number = int(img1.shape[3] / k2)
        # torch.ones
        eme = 0.
        for j in range(y_number):
            for i in range(x_number):
                patch1 = img1[0, 0, k1 * i: k1 * (i + 1), k2 * j: k2 * (j + 1)]
                patch2 = img2[0, 0, k1 * i: k1 * (i + 1), k2 * j: k2 * (j + 1)]
                patch_1 = torch.mean(patch1)
                patch_2 = torch.mean(patch2)

                eme = patch_2 / (patch_1 + 1) + eme
        # print(eme)
        # print((x_number * y_number) / (eme + 0.0001))
        return  eme/(x_number * y_number)/k1/k2

    def eme_loss3(self, img1):
        gradx = img1[:, :, 1:, :] - img1[:, :, :-1, :]
        grady = img1[:, :, :, 1:] - img1[:, :, :, :-1]

        eme = 1/(torch.mean(torch.abs(gradx))+torch.mean(torch.abs(grady)))
        # print(eme)
        # print((x_number * y_number) / (eme + 0.0001))
        return  0.000001*eme

    def enhancement_measurement(im, block_size=3, metric='sdme', alpha=0.75):
        """
        Compute a Measure of Enhancement by Panetta et al [4]. There are several related measures that
        all take the following form:
            1/n * sum(20 * log_10(metric))
        for standard measures and the following for entropic measures:
            1/n * sum(alpha*metric^alpha * log_10(alpha*metric^alpha))    ?
        where the metric is computed over n non-overlapping blocks in the image. The sum operates over
        all blocks. The metrics are defined in terms of the maximum and minimum values in the blocks:
        B_max and B_min respectively. Any block for which the metric is 0 or undefined (divide by 0)
        will not be counted.
        The following metrics are defined:
            EME - Measure of Enhancement - Weber-law-based [1,2]
            metric = B_max / B_min
            AME - Advanced Measure of Enhancement - Michelson-law-based [2]
            metric = (B_max+B_min) / (B_max-B_min)
            SDME - Secord-Derivative-Like Measure of Enhancement [4]
            metric = |(B_max+B_min+2*B_center)/(B_max+B_min-2*B_center)|
        where B_center is the intensity of the pixel in the center of the block for SDME. Any of these
        metrics can be given as the metric parameter. Appending an "E" to the name will use the entropic
        measure. The size of the blocks is given by block_size (which can be a scalar or sequence) and
        defaults to 3x3. The entropic measures require an alpha parameter which defaults to 0.75. The
        value of alpha can also be a sequence in which case a sequence of values is returned for the
        alphas. This is significantly faster than calling this function with separate values of alpha.
        All of these have higher values to indicate "enhancement" and higher is better.
        Currently the logAME/logAMEE (Logarithmic AME / Integrated PLIP operators from [3]) are not
        included.
        REFERENCES
         1. Agaian S S, Panetta K, and Grigoryan A M, Mar 2001, "Transform-based image enhancement
            algorithms with performance measure", IEEE Transactions on Image Processing, 10(3):367382.
         2. Agaian S S, Silver B, and Panetta K A, Mar 2007, "Transform coefficient histogram-based
            image enhancement algorithms using contrast entropy", IEEE Transactions on Image Processing,
            16(3):741758.
         3. Panetta K A, Wharton E J, and Agaian S S, Feb 2008, "Human visual system-based image
            enhancement and logarithmic contrast measure", IEEE Transactions on Systems, Man,
            Cybernetics, 38(1):174188.
         4. Panetta K, Zhou Y, Agaian S, Jia H, Nov 2011, "Nonlinear unsharp masking for mammogram
            enhancement", IEEE Transactions on IT in Biomedicine, 15(6):918-928.
        """
        # TODO: test, get response, and also just implement using convolutions like in measures.m?
        # Also, EME has a divide-by-0 issue? their code picks the second-minimum
        # TODO: support masks
        from numpy import abs, isfinite  # pylint: disable=redefined-builtin
        im = check_image_single_channel(im)
        metric = metric.lower()
        if metric not in ('eme', 'emee', 'ame', 'amee', 'logame', 'logamee', 'sdme', 'sdmee'):
            raise ValueError('metric')
        alpha = asarray(alpha if isinstance(alpha, Sequence) else [alpha])
        if alpha.ndim != 1 or alpha.size == 0 or ((alpha <= 0) | (alpha > 1)).any():
            raise ValueError('alpha')

        if metric[:4] == 'sdme':
            maxes, mins, centers = __calc_block_min_max(im, block_size, True)
        else:
            maxes, mins = __calc_block_min_max(im, block_size)
        maxes = maxes.astype(float, copy=False)

        # Calculate the numerator and denominator for each metric
        entropic = metric[-2:] == 'ee'
        if entropic: metric = metric[:-1]
        if metric == 'eme':
            numer, denom = maxes, mins
        elif metric == 'ame':
            numer, denom = maxes + mins, maxes - mins
        elif metric == 'logame':
            raise NotImplementedError('logame')
        elif metric == 'sdme':
            maxes += mins
            numer, denom = maxes + 2 * centers, maxes - 2 * centers

        # Adjust metric values for undefined, infinities, 0 values, and negatives and divide
        # denom += 0.0001
        mask = numer != 0
        mask &= denom != 0
        mask &= isfinite(numer)
        mask &= isfinite(denom)
        metric = numer[mask] / denom[mask]
        abs(metric, metric)

        # Measure of Enhancement (standard)
        # In theory we could do log(metric.prod()) which would be faster but that overflows
        if not entropic: return 20 / metric.size * log10(metric, metric).sum()

        # Measure of Enhancement by Entropy (with many alphas)
        scale = alpha / metric.size
        alpha, metric = alpha[None, :], metric[:, None]
        return scale * (metric ** alpha * log10(metric)).sum()

    def __calc_block_min_max(im, block_size, compute_centers=False):  # pylint: disable=too-many-locals
        """
        Calculate the minimum and maximum (and possibly the center values) of all blocks in an image.
        This includes all of the blocks that don't quite fit along the edges.
        """
        from numpy import amin, amax, copyto, fromiter
        from .util import block_view, reduce_blocks, tuple_set

        block_size = tuple(block_size) if isinstance(block_size, Sequence) else ((block_size,) * im.ndim)
        if len(block_size) != im.ndim or any(bs < 1 for bs in block_size):
            raise ValueError('block_size')

        # Shape of the data after the blocking
        # up means round up, down means round down
        shape_up = tuple((x + sz - 1) // sz for x, sz in zip(im.shape, block_size))
        slice_down = tuple(slice(x // sz) for x, sz in zip(im.shape, block_size))
        slice_all = (slice(None),) * im.ndim

        # Get the blocks that cover the majority of the image
        blocks = block_view(im, block_size)

        # Get the bulk of the values
        maxes = empty(shape_up, im.dtype)
        reduce_blocks(blocks, amax, maxes[slice_down])
        mins = empty(shape_up, im.dtype)
        reduce_blocks(blocks, amin, mins[slice_down])
        if compute_centers:
            centers = empty(shape_up, im.dtype)
            copyto(centers[slice_down], blocks[slice_all[:im.ndim] + tuple(sz // 2 for sz in block_size)])

        # Compute the values for remainders
        # We need to do this for every combination of axes
        remainder = fromiter((x % sz for x, sz in zip(im.shape, block_size)), int)
        for inds in axes_combinations(im.ndim):
            inds = list(inds)
            if (remainder[inds] == 0).any(): continue  # no remainder for this combination

            # Compute the slices and sizes of the remainders for this combination of axes
            im_slc_ = tuple_set(slice_all, [slice(im.shape[i] - remainder[i], None) for i in inds], inds)
            block_size_ = tuple_set(block_size, remainder[inds], inds)
            slice_ = tuple_set(slice_down, (slice(-1, None),) * len(inds), inds)

            # Get the remainder blocks and then compute the values
            blocks = block_view(im[im_slc_], block_size_)
            reduce_blocks(blocks, amax, maxes[slice_])
            reduce_blocks(blocks, amin, mins[slice_])
            if compute_centers:
                copyto(centers[slice_], blocks[slice_all[:im.ndim] + tuple(sz // 2 for sz in block_size_)])

        # Done
        return (maxes, mins, centers) if compute_centers else (maxes, mins)

    def get_seg_loss(self, enhanced_image):
        # segment the enhanced image
        seg_input = enhanced_image.to(device)
        seg_output = self.seg(seg_input).to(device)

        # build seg output
        target = (get_NoGT_target(seg_output)).data.to(device)

        # calculate seg. loss
        seg_loss = self.seg_criterion(seg_output, target)

        return seg_loss

    def get_NoGT_target(inputs):
        sfmx_inputs = F.log_softmax(inputs, dim=1)
        target = torch.argmax(sfmx_inputs, dim=1)
        return target

    def gradient(self, input_tensor, direction):
        self.smooth_kernel_x = torch.FloatTensor([[0, 0], [-1, 1]]).view((1, 1, 2, 2)).cuda()
        self.smooth_kernel_y = torch.transpose(self.smooth_kernel_x, 2, 3)

        if direction == "x":
            kernel = self.smooth_kernel_x
        elif direction == "y":
            kernel = self.smooth_kernel_y
        grad_out = torch.abs(F.conv2d(input_tensor, kernel,
                                      stride=1, padding=1))
        return grad_out

    def ave_gradient(self, input_tensor, direction):
        return F.avg_pool2d(self.gradient(input_tensor, direction),
                            kernel_size=5, stride=1, padding=2)

    def smooth(self, input_I, input_R):
        # input_R = 0.299*input_R[:, 0, :, :] + 0.587*input_R[:, 1, :, :] + 0.114*input_R[:, 2, :, :]
        # input_R = torch.unsqueeze(input_R, dim=1)
        return torch.mean(self.gradient(input_I, "x") * torch.exp(-12 * self.ave_gradient(input_R, "x")) +
                          self.gradient(input_I, "y") * torch.exp(-12 * self.ave_gradient(input_R, "y")))

    def _init_loss(self):
        self.mse_loss = torch.nn.MSELoss().type(self.data_type)
        self.blur_loss = StdLoss().type(self.data_type)
        self.L1_loss = torch.nn.L1Loss().type(self.data_type)
        self.TVLoss = L1_TVLoss_Charbonnier().type(self.data_type)
        self.VggLoss = VggLoss().type(self.data_type)
        self.Smooth_loss = conlight_loss().type(self.data_type)
        self.Light_loss = Rclahe_loss().type(self.data_type)
        self.exclusionLoss = ExclusionLoss().type(self.data_type)
        self.SCILoss = SmoothLoss().type(self.data_type)
        self.L_SPC8 = L_spa8().type(self.data_type)
        self.L_EXP = L_exp().type(self.data_type)
        self.L1_EXP = L_TV().type(self.data_type)
    def _init_inputs(self):
        self.inputs = torch.cat([np_to_torch(self.I0).cuda().type(self.data_type),
                                 np_to_torch(self.I90).cuda().type(self.data_type)], 1)
        # self.J_net_inputs = torch.cat([np_to_torch(self.I0).cuda().type(self.data_type),
        #                                np_to_torch(self.I90).cuda().type(self.data_type)], 1)
        # self.mask_net_inputs = np_to_torch(self.image).cuda().type(self.data_type)
        # self.ambient_net_input = np_to_torch(self.image).cuda().type(self.data_type)

    def _init_all(self):
        self._init_images()
        self._init_nets()
        self._init_ambient()
        self._init_inputs()
        self._init_parameters()
        self._init_loss()

    def optimize(self):
        torch.backends.cudnn.enabled = True
        torch.backends.cudnn.benchmark = True

        optimizer = torch.optim.Adam(self.parameters, lr=self.learning_rate)
        for j in range(self.num_iter):
            optimizer.zero_grad()
            self._optimization_closure(j)
            self._obtain_current_result(j)
            self._plot_closure(j)
            optimizer.step()
            if j % 200 == 0:
                self.finalize(steps=j)




    def _optimization_closure(self, step):
        """
        :param step: the number of the iteration
        :return:
        """
        self.S = self.I0_torch + self.I90_torch
        self.I_minus = self.I0_torch - self.I90_torch

        self.t_out = self.t_net(torch.cat([self.I_minus, self.S], 1))
        self.ambient_out = self.A_net(self.inputs)

        self.J_out = (self.S - self.ambient_out * (1 - self.t_out))/self.t_out

        self.R_out = self.R_net(torch.cat([self.J_out, self.S], 1))
        self.I_out = self.J_out / self.R_out



        self.S_out = self.J_out * self.t_out + self.ambient_out * (1 - self.t_out)
        # self.t_out = 1 - self.S_out * self.P_out / (self.ambient_out * 1.13)
        self.res_loss_S = self.mse_loss(self.S, self.S_out)

        # self.res_loss_J = self.mse_loss(self.J_res, self.J_out)
        # self.P_loss = self.L1_loss(self.PI * self.I, self.PD_out * self.D + self.PA_out * self.ambient_out)
        # self.noRef_loss = torch.tensor(0)
        # noRef_loss = self.VggLoss(self.R_out, self.S)
        self.noRef_loss = self.eme_loss3(self.J_out )+self.eme_loss3(self.S_out )
        # self.mseloss = self.mse_loss(self.mask_out * self.image_out + (1 - self.mask_out) * self.ambient_out,
        #                              self.image_torch)

        # hsv = np_to_torch(rgb2hsv(torch_to_np(self.image_out).transpose(1, 2, 0)))
        # cap_prior = hsv[:, :, :, 2] - hsv[:, :, :, 1]
        # self.cap_loss = self.mse_loss(cap_prior, torch.zeros_like(cap_prior))
        # vae_loss = self.ambient_net.getLoss()
        # self.total_loss = self.res_loss_I
        # self.total_loss = self.total_loss + self.res_loss_J
        # self.total_loss = self.total_loss + self.P_loss

        # TTV_loss = 0.1 * self.TVLoss(self.t_out)
        ITV_loss = self.TVLoss(self.I_out)
        blur_loss = self.blur_loss(self.ambient_out)
        # smoothloss = 0.001*self.Smooth_loss(self.I_out,self.R_out)
        # lightloss  = 0.0001*self.Light_loss(self.S,self.R_out)
        # smoothloss  = self.SCILoss(self.S, self.I_out)
        # Exclusion_Loss = self.exclusionLoss(self.I_out, self.R_out)
        L_SPC_loss1 = self.L_SPC8(self.S_out, self.S,8)
        L_SPC_loss2 = self.L_SPC8(self.S_out , self.R_out,8)
        # L_EXP_loss = self.L_EXP(self.I_out, torch.mean(self.S))
        L1_EXP_loss = self.L1_EXP(self.I_out)
        # loss_seg = self.get_seg_loss(self.R_out)
        Ismooth_loss_low = self.smooth(self.I_out, self.R_out)

        self.total_loss = 10*self.res_loss_S
        self.total_loss = self.total_loss + self.noRef_loss
        # self.total_loss = self.total_loss + 0.01 * vae_loss
        # self.total_loss = self.total_loss + 0.01 * smoothloss
        # self.total_loss = self.total_loss + 0.1 * Exclusion_Loss
        # self.total_loss = self.total_loss + 0.01 * blur_loss
        self.total_loss = self.total_loss + 0.1*L_SPC_loss1
        self.total_loss = self.total_loss + 0.1*L_SPC_loss2
        self.total_loss = self.total_loss + 0.01 * Ismooth_loss_low
        # self.total_loss = self.total_loss + 0.01 * L_EXP_loss
        self.total_loss = self.total_loss + 0.01 * L1_EXP_loss
        # self.total_loss = self.total_loss + 0.1 *  loss_seg
        self.total_loss = self.total_loss + 0.001 *ITV_loss

        if step < 500:
            self.res_loss_t = self.mse_loss(self.t_out, 1 - self.S * self.I_minus / torch.max(self.S ) / 1.13)
            self.total_loss = self.total_loss + 0.1 * self.res_loss_t
            self.res_loss_L = self.mse_loss(self.J_out, self.S /self.t_out)
            self.total_loss = self.total_loss + 0.1 * self.res_loss_L
            self.total_loss = self.total_loss + self.mse_loss(self.ambient_out, self.ambient_val * torch.ones_like(self.ambient_out))
        print(self.total_loss.item())
        self.total_loss.backward(retain_graph=True)



    def _obtain_current_result(self, step):
        if step % 200 == 0:
            # J_out_np = np.clip(torch_to_np(self.J_out), 0, 1)
            J_out_np = np.clip(torch_to_np(self.J_out), 0, 2)
            J_out_np = (J_out_np - J_out_np.min()) / (J_out_np.max() - J_out_np.min())
            # PD_out_np = np.clip(torch_to_np(self.PD_out), 0, 1)
            # G_out_np = np.clip(torch_to_np(self.G_out), 0, 1)
            ambient_out_np = np.clip(torch_to_np(self.ambient_out), 0, 2)
            P_res_out = np.clip(torch_to_np(self.ambient_out), 0, 2)
            t_out_np = np.clip(torch_to_np(self.t_out), 0, 2)
            S_res_out = np.clip(torch_to_np(self.S_out), 0, 2)
            # S_res_out = (S_res_out - S_res_out.min()) / (S_res_out.max() - S_res_out.min())
            R_res_out = np.clip(torch_to_np(self.R_out), 0, 2)
            R_res_out = (R_res_out - R_res_out.min()) / (R_res_out.max() - R_res_out.min())
            I_res_out = np.clip(torch_to_np(self.I_out), 0, 2)
            I_res_out = (I_res_out - I_res_out.min()) / (I_res_out.max() - I_res_out.min())
            # mask_out_np = self.t_matting(mask_out_np) # DONT KNOW DELET IF CORRECT
            S = np.clip(torch_to_np(self.S), 0, 2)
            self.current_result = DehazeResult_PYOLY(learned=J_out_np, a=ambient_out_np, t=t_out_np, S_res=S_res_out, I_res=I_res_out, R_res=R_res_out, P_res=P_res_out, S_Ori = S)

    def _plot_closure(self, step):
        print('Iteration %05d    Loss %f %f %f %0.4f%% \n' % (
            step, self.total_loss.item(), self.res_loss_S.item(), self.res_loss_t.item(), ((self.res_loss_S.item()+self.res_loss_S.item()) / self.total_loss).item()),
              '\r', end='')

    def finalize(self, steps=200):

        if not os.path.exists(self.output_path):
            os.mkdir(self.output_path)
            os.mkdir(self.output_path + 'J/')
            os.mkdir(self.output_path + 'J_res/')
            os.mkdir(self.output_path + 'A/')
            os.mkdir(self.output_path + 'T/')
            os.mkdir(self.output_path + 'I_res/')
            os.mkdir(self.output_path + 'P_res/')
            os.mkdir(self.output_path + 'S_res/')
            os.mkdir(self.output_path + 'R_res/')
            os.mkdir(self.output_path + 'G_res/')

        final_A = np_imresize(self.current_result.a, output_shape=self.I0.shape[1:])
        final_J = np_imresize(self.current_result.learned, output_shape=self.I0.shape[1:])
        final_t = np_imresize(self.current_result.t, output_shape=self.I0.shape[1:])
        final_S = np_imresize(self.current_result.S_res, output_shape=self.I0.shape[1:])
        final_I = np_imresize(self.current_result.I_res, output_shape=self.I0.shape[1:])
        final_P = np_imresize(self.current_result.P_res, output_shape=self.I0.shape[1:])
        final_R = np_imresize(self.current_result.R_res, output_shape=self.I0.shape[1:])
        # final_G = np_imresize(self.current_result.G_res, output_shape=self.I0.shape[1:])


        post = np.clip((torch_to_np(self.S_out) - ((1 - final_t) * final_A)) / (final_t * 2), 0, 2)
        post = (post  - post .min()) / (post .max() - post .min())
        save_image(self.image_name, final_J, self.output_path + 'J/' + str(steps) + '/')
        save_image(self.image_name, post, self.output_path + 'J_res/' + str(steps) + '/')
        save_image(self.image_name, final_A, self.output_path + 'A/' + str(steps) + '/')
        save_image(self.image_name, final_t, self.output_path + 'T/' + str(steps) + '/')
        save_image(self.image_name, final_S, self.output_path + 'S_res/' + str(steps) + '/')
        save_image(self.image_name, final_I, self.output_path + 'I_res/' + str(steps) + '/')
        save_image(self.image_name, final_P, self.output_path + 'P_res/' + str(steps) + '/')
        save_image(self.image_name, final_R, self.output_path + 'R_res/' + str(steps) + '/')
        # save_image(self.image_name, final_G, self.output_path + 'G_res/' + str(steps) + '/')
        # post = np.clip((self.image - ((1 - final_t) * final_a)) / final_t, 0, 1)
        # save_image(self.image_name, post, self.output_path + 'Normal/' + str(steps) + '/')
        if steps==200:
            S_Ori = np_imresize(self.current_result.S_Ori, output_shape=self.I0.shape[1:])
            save_image(self.image_name, S_Ori, self.output_path )
        # final_t = self.t_matting(final_t)
        # post = np.clip((self.image - ((1 - final_t) * final_a)) / final_t, 0, 1)
        # save_image(self.image_name, post, self.output_path + 'Matting/' + str(steps) + '/')

    # def t_matting(self, mask_out_np):
    #     refine_t = guidedFilter(self.image.transpose(1, 2, 0).astype(np.float32),
    #                             mask_out_np[0].astype(np.float32), 50, 1e-4)
    #     if self.clip:
    #         return np.array([np.clip(refine_t, 0.1, 1)])
    #     else:
    #         return np.array([np.clip(refine_t, 0, 1)])


def dehazing(opt):
    torch.cuda.set_device(opt.cuda)

    # extensions = ['png', 'jpg', 'jpeg']
    # hazy_add = 'data/' + opt.datasets + '/' + '*.png'
    hazy_add = 'data2/' + '*.bmp'

    for item in sorted(glob.glob(hazy_add)):
        print(item)

        name = item.split('.')[0].split('/')[1]
        if "min" in name:
            continue
        else:
            I_0_name = item
            I_90_name = item.replace('max', 'min')

        print(name)

        I_0 = prepare_image(I_0_name)  # (1, 1024, 1216)
        I_90 = prepare_image(I_90_name)  # (1, 1024, 1216)
        I_0 = I_0
        I_90 = I_90
        dh = Dehaze(name, I_0, I_90, opt)
        # dh = Dehaze(name, hazy_img, opt)
        dh.optimize()
        dh.finalize()


if __name__ == "__main__":
    dehazing(options2)

