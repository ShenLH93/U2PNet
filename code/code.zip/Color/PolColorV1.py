#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Jan 11 10:36:59 2020

@author: lester
"""
from collections import namedtuple
from cv2.ximgproc import guidedFilter
from net.losses import StdLoss
from utils.imresize import imresize, np_imresize
from utils.image_io import *
from skimage.color import rgb2hsv
import torch
import torch.nn as nn
from net2.vae import VAE
import numpy as np

from net2.Net_color1 import Net, Net2, DCENet, Net3
from options2 import options2
from TVLoss.L1_TVLoss import L1_TVLoss_Charbonnier
from Gloss.Gsmoothloss import conlight_loss
from Gloss.GClaheloss import *

import torch.nn.functional as F
import cv2
from rgb_hsv import RGB_HSV
import matplotlib.pyplot as plt
import csv

os.environ["CUDA_VISIBLE_DEVICES"] = "9"
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

DehazeResult_PYOLY = namedtuple("DehazeResult", ['learned', 'a', 't', 'S_res'])


class Dehaze(object):

    def __init__(self, image_name, I0, I90, opt):
        self.image_name = image_name
        self.I0 = I0
        self.I90 = I90
        self.num_iter = opt.num_iter

        self.ambient_net = None
        self.image_net = None
        self.mask_net = None
        self.ambient_val = None
        self.mse_loss = None
        self.learning_rate = opt.learning_rate
        self.parameters = None
        self.current_result = None
        self.output_path = "output/" + opt.datasets + '_J_new/'
        self.patch_size = 4
        self.data_type = torch.cuda.FloatTensor
        self.clip = opt.clip
        self.blur_loss = None
        self.best_result = None
        self.best_result_ssim = None
        self.image_net_inputs = None
        self.mask_net_inputs = None
        self.image_out = None
        self.mask_out = None
        self.ambient_out = None
        self.total_loss = None
        self._init_all()

        self.input = None
        self.output = None

    def _init_images(self):
        self.original_image = self.I0.copy()
        factor = 1
        image_I0 = self.I0
        image_I90 = self.I90
        image_size = 1000

        while image_I0.shape[1] >= image_size or image_I0.shape[2] >= image_size:
            new_shape_x, new_shape_y = self.I0.shape[1] / factor, self.I0.shape[2] / factor
            new_shape_x -= (new_shape_x % 32)
            new_shape_y -= (new_shape_y % 32)
            image_I0 = np_imresize(self.I0, output_shape=(new_shape_x, new_shape_y))
            image_I90 = np_imresize(self.I90, output_shape=(new_shape_x, new_shape_y))
            factor = 1 + factor

        self.I0 = image_I0
        self.I90 = image_I90

        self.I0_torch = np_to_torch(self.I0).type(torch.cuda.FloatTensor)
        self.I90_torch = np_to_torch(self.I90).type(torch.cuda.FloatTensor)

    def _init_nets(self):
        J_net = Net3(out_channel=3)
        R_net = DCENet(n=4, return_results=[2, 4])
        A_net = Net(out_channel=3, I0=self.I0_torch)
        t_net = Net2(out_channel=3)
        A_net2 = Net2(out_channel=3)

        self.J_net = J_net.type(self.data_type)
        self.R_net = R_net.type(self.data_type)
        self.A_net = A_net.type(self.data_type)
        self.A2_net = A_net2.type(self.data_type)
        self.t_net = t_net.type(self.data_type)

    def _init_ambient(self):
        ambient_net = VAE(self.I0.shape)
        self.ambient_net = ambient_net.type(torch.cuda.FloatTensor)

    def _init_parameters(self):
        parameters = [p for p in self.J_net.parameters()] + \
                     [p for p in self.R_net.parameters()] + \
                     [p for p in self.A_net.parameters()] + \
                     [p for p in self.A2_net.parameters()] + \
                     [p for p in self.ambient_net.parameters()]

        self.parameters = parameters

    def exposure_control_loss2(self, originals, enhances, rsize=16, E=0.8):
        avg_enhance = F.avg_pool2d(enhances, rsize).mean(1)  # to gray: (R+G+B)/3
        avg_ori = F.avg_pool2d(originals, rsize).mean(1)
        Eney = torch.clamp(E * avg_ori, 0.1, 1)

        exp_loss = (avg_enhance - Eney).abs().mean()
        return exp_loss

    def color_constency_loss2(self, enhances, originals, rsize=5):
        enhances = F.avg_pool2d(enhances, rsize)
        originals = F.avg_pool2d(originals, rsize)
        enh_cols = enhances + 0.1
        ori_cols = originals + 0.1
        rg_ratio = (enh_cols[:, 0] / enh_cols[:, 1] - ori_cols[:, 0] / ori_cols[:, 1]).abs()
        gb_ratio = (enh_cols[:, 1] / enh_cols[:, 2] - ori_cols[:, 1] / ori_cols[:, 2]).abs()
        br_ratio = (enh_cols[:, 2] / enh_cols[:, 0] - ori_cols[:, 2] / ori_cols[:, 0]).abs()
        col_loss = (rg_ratio + gb_ratio + br_ratio).mean()
        return col_loss

    def get_dark_channel(self, I, w):
        _, _, H, W = I.shape
        maxpool = nn.MaxPool3d((3, w, w), stride=1, padding=(0, w // 2, w // 2))
        dc = maxpool(0 - I[:, :, :, :])
        return -dc

    def get_light_channel(self, I, w):
        _, _, H, W = I.shape
        maxpool = nn.MaxPool3d((3, w, w), stride=1, padding=(0, w // 2, w // 2))
        lc = maxpool(I[:, :, :, :])
        return lc

    def t_matting(self, mask_out_np, mask, rsize):
        refine_t = guidedFilter(mask.transpose(1, 2, 0).astype(np.float32),
                                mask_out_np.transpose(1, 2, 0).astype(np.float32), rsize, 1e-4)
        refine_t = refine_t.transpose(2, 0, 1)
        if self.clip:
            return np.clip(refine_t, 0.1, 1)
        else:
            return np.clip(refine_t, 0, 1)

    def S_clahe(self, img):
        img = img * 255
        channel1 = img.transpose(1, 2, 0).astype(np.uint8)
        clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(4, 4))
        cl1 = clahe.apply(channel1)
        return cl1

    def _init_loss(self):
        self.mse_loss = torch.nn.MSELoss().type(self.data_type)
        self.L_SPC8 = L_spa8().type(self.data_type)

    def _init_inputs(self):
        self.inputs = torch.cat([np_to_torch(self.I0).cuda().type(self.data_type),
                                 np_to_torch(self.I90).cuda().type(self.data_type)], 1)

    def _init_all(self):
        self._init_images()
        self._init_nets()
        self._init_ambient()
        self._init_inputs()
        self._init_parameters()
        self._init_loss()

    def optimize(self):
        torch.backends.cudnn.enabled = True
        torch.backends.cudnn.benchmark = True
        optimizer = torch.optim.Adam(self.parameters, lr=self.learning_rate)
        loss = []
        iteration = []

        for j in range(self.num_iter):
            optimizer.zero_grad()
            self._optimization_closure(j)
            self._obtain_current_result(j)
            optimizer.step()
            iteration.append(j)  # i是你的iter
            loss.append(self.total_loss.item())  # total_loss.item()是你每一次inter输出的loss

            if j % 100 == 0:
                self._plot_closure(j)
            if j % 300 == 0:
                self.finalize(steps=j)
                print(self.rD)
                print(self.rL)
                print(self.rJ)
                print(self.E)

    def _optimization_closure(self, step):
        self.S = self.I0_torch + self.I90_torch
        self.I_minus = self.I0_torch - self.I90_torch
        self.P = self.I_minus / (self.S)

        S_channel = torch.split(self.S, 1, 1)
        S_np1 = torch_to_np(S_channel[0] / torch.max(self.S))
        S_np2 = torch_to_np(S_channel[1] / torch.max(self.S))
        S_np3 = torch_to_np(S_channel[2] / torch.max(self.S))
        S_Clahe_np1 = self.S_clahe(S_np1)
        S_Clahe_np2 = self.S_clahe(S_np2)
        S_Clahe_np3 = self.S_clahe(S_np3)

        S_Clahe_torch1 = np_to_torch(S_Clahe_np1).type(torch.float32).unsqueeze(0)
        S_Clahe_torch2 = np_to_torch(S_Clahe_np2).type(torch.float32).unsqueeze(0)
        S_Clahe_torch3 = np_to_torch(S_Clahe_np3).type(torch.float32).unsqueeze(0)

        self.SCLAHE = torch.cat([S_Clahe_torch1.cuda(),
                                 S_Clahe_torch2.cuda(),
                                 S_Clahe_torch3.cuda()], 1)
        self.SCLAHE2 = (self.SCLAHE - torch.min(self.SCLAHE)) / (torch.max(self.SCLAHE) - torch.min(self.SCLAHE))

        self.P_np = torch_to_np(self.P)
        self.P_np = self.t_matting(self.P_np, self.P_np, 10)
        self.P = np_to_torch(self.P_np)

        self.t_out = self.t_net(self.inputs)
        self.t_out = torch.clamp(self.t_out, 0.1, 1)

        self.ambient_out = self.A_net(self.S)
        self.ambient_out = torch.clamp(self.ambient_out, 0.1, 1)

        self.J_out = (self.S - self.ambient_out * (1 - self.t_out)) / (self.t_out)
        self.J_out = torch.clamp(self.J_out, 0.01, 1)

        self.J_out = self.J_out / torch.max(self.J_out)

        self.S_out = self.J_out * self.t_out + self.ambient_out * (1 - self.t_out)

        DCh = self.get_dark_channel(self.S / 2, 15)
        self.DC = torch.mean(DCh)
        LCh = self.get_light_channel(self.S / 2, 15)
        self.LCh = torch.mean(LCh)

        self.rD = 30 / 255 / self.DC
        self.rL = 30 / 255 / self.LCh

        self.rJ = 1 / 2 * (self.rD + self.rL)
        self.E = 1
        if self.rD > 1:
            self.E = self.rJ * self.rJ * 0.1
        if self.rL < 1:
            self.E = self.rJ * self.rJ * 10

        self.E = torch.clamp(self.E, min=0.0001, max=100)

        self.res_loss = self.mse_loss(self.SCLAHE2, self.S_out)
        self.p2 = (self.P - torch.min(self.P)) / (torch.max(self.P) - torch.min(self.P))

        L_SPC_loss1 = self.L_SPC8(self.t_out, 1 - self.p2, 1)
        L_SPC_loss2 = self.L_SPC8(self.J_out, self.SCLAHE2, 1)

        CCL = self.color_constency_loss2(self.J_out, self.S, rsize=5)
        ECL = self.exposure_control_loss2(self.SCLAHE2, self.J_out, rsize=2, E=self.E)

        self.total_loss = 0.1 * self.res_loss
        self.total_loss = self.total_loss + 0.01 * L_SPC_loss1
        self.total_loss = self.total_loss + 0.01 * L_SPC_loss2
        self.total_loss = self.total_loss + 0.1 * CCL + 0.5 * ECL
        self.total_loss.backward(retain_graph=True)

    def _obtain_current_result(self, step):
        if step % 20 == 0:
            J_out_np = torch_to_np(self.J_out)
            ambient_out_np = torch_to_np(self.ambient_out)
            t_out_np = torch_to_np(self.t_out)
            S_res_out = torch_to_np(self.S_out)
            self.current_result = DehazeResult_PYOLY(learned=J_out_np, a=ambient_out_np, t=t_out_np, S_res=S_res_out)

    def _plot_closure(self, step):
        print('Iteration %05d    Loss %f  \n' % (
            step, self.total_loss.item()),
              '\r', end='')

    def finalize(self, steps=200):

        if not os.path.exists(self.output_path):
            os.mkdir(self.output_path)
            os.mkdir(self.output_path + 'J/')
            os.mkdir(self.output_path + 'J_res/')
            os.mkdir(self.output_path + 'A/')
            os.mkdir(self.output_path + 'T/')

        final_A = np_imresize(self.current_result.a, output_shape=self.I0.shape[1:])
        final_J = np_imresize(self.current_result.learned, output_shape=self.I0.shape[1:])
        final_t = np_imresize(self.current_result.t, output_shape=self.I0.shape[1:])
        final_S = np_imresize(self.current_result.S_res, output_shape=self.I0.shape[1:])

        post = (final_S - ((1 - final_t) * final_A)) / (final_t)
        post = post / post.max()
        save_image(self.image_name, post, self.output_path + 'J_res/' + str(steps) + '/')
        save_image(self.image_name, final_J, self.output_path + 'J/' + str(steps) + '/')
        save_image(self.image_name, final_A, self.output_path + 'A/' + str(steps) + '/')
        post2 = (final_t - final_t.min()) / (final_t.max() - final_t.min())
        save_image(self.image_name, post2, self.output_path + 'T/' + str(steps) + '/')


def dehazing(opt):
    torch.cuda.set_device(opt.cuda)

    hazy_add = 'data9/' + '*.bmp'

    for item in sorted(glob.glob(hazy_add)):
        print(item)

        name = item.split('.')[0].split('/')[1]
        if "min" in name:
            continue
        else:
            I_0_name = item
            I_90_name = item.replace('max', 'min')

        print(name)

        I_0 = prepare_image(I_0_name)
        I_90 = prepare_image(I_90_name)
        I_0 = I_0
        I_90 = I_90
        dh = Dehaze(name, I_0, I_90, opt)

        dh.optimize()
        dh.finalize()


if __name__ == "__main__":
    dehazing(options2)
