"""
Created on 2020/1/14

@author: Boyun Li
"""

import argparse

parser = argparse.ArgumentParser()

# Input Parameters
parser.add_argument('--cuda', type=int, default=9)
parser.add_argument('--name', type=str, default="SOTS_GT")
parser.add_argument('--datasets', type=str, default="Output")
parser.add_argument('--clip', type=bool, default=True)
parser.add_argument('--num_iter', type=int, default=201)
parser.add_argument('--learning_rate', type=float, default=0.001)
parser.add_argument("--num_of_SegClass", type=int, default=21, help='Number of Segmentation Classes, default VOC = 21')
options2 = parser.parse_args()
