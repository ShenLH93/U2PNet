import torch
import torch.nn as nn



class conlight_loss(nn.Module):

    def __init__(self):

        super(conlight_loss, self).__init__()



    def forward(self, x1,x2):
        h_tv1 = torch.abs((x1[:, :, 1:, :] - x1[:, :, :-1, :]))
        h_tv2 = torch.abs((x2[:, :, 1:, :] - x2[:, :, :-1, :]))
        w_tv1 = torch.abs((x1[:, :, :, 1:] - x1[:, :, :, :-1]))
        w_tv2 = torch.abs((x2[:, :, :, 1:] - x2[:, :, :, :-1]))
        loss = torch.mean(h_tv1 * torch.exp(-10 * h_tv2)) +  torch.mean(w_tv1 *torch.exp(-10 * w_tv2))#+another_
        return loss
